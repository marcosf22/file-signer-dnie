import textwrap
from smartcard.System import readers # Librería para acceder físicamente al lector.
from smartcard.Exceptions import *
import PyKCS11 # Biblioteca para interactuar con tarjetas inteligentes (PKCS#11)
import pkcs11 # Librería para hacer todo xd.
from pkcs11 import ObjectClass, Attribute, Mechanism
import getpass # Librería para ocultar el PIN.
import base64 # Librería para pasar a base64.
from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding

def exportCert():

    # Aquí literalmente ponemos la ruta donde está el archivo este.
    lib = pkcs11.lib("C:\Program Files\OpenSC Project\OpenSC\pkcs11\opensc-pkcs11.dll")

    # Comprobamos que el lector está enchufado.
    lectores = readers()
    if not lectores:
        raise SystemExit("No hay lectores detectados")
    lector = lectores[0]
    print("Lectura correcta por: ", lector)

    try:

        # Creamos la conexión con el DNI.
        conn = lector.createConnection()
        conn.connect()

        token = lib.get_token()
        print("Token:", token)

        with token.open(user_pin=getpass.getpass("Introduce el PIN del DNIe: ")) as sesion:
            print('Inicio correcto')   

            # Extraemos los certificados que haya en el DNI.
            certificados = list(sesion.get_objects({Attribute.CLASS: ObjectClass.CERTIFICATE}))  
            print(len(certificados), " certificados encontrados")
                
            # Guardamos el certificado de firma en un archivo .DER.
            for certificado in certificados:
 
                print(f"Certificado tipo: {certificado[pkcs11.Attribute.LABEL]}")

                if certificado[pkcs11.Attribute.LABEL] == "CertFirmaDigital":
                    der = certificado[pkcs11.Attribute.VALUE]
                    cert=x509.load_der_x509_certificate(bytes(der),default_backend())
                    with open('certificado.der', 'wb') as g:
                        g.write(der)

                    # Lo pasamos a formato .PEM.
                    b64 = base64.b64encode(der).decode('ascii')
                    pem = "-----BEGIN CERTIFICATE-----\n" + "\n".join(textwrap.wrap(b64, 64)) + "\n-----END CERTIFICATE-----\n"
                    with open("certificado.pem", "w") as f:
                        f.write(pem)
                    print("Certificado de firma guardado en certificado.der y certificado.pem")

            private_keys = sesion.get_objects({Attribute.CLASS: ObjectClass.PRIVATE_KEY})
            
            for i, key in enumerate(private_keys):
                print(f"Clave de tipo: {key[Attribute.LABEL]}")
                if(key[Attribute.LABEL] == 'KprivFirmaDigital'):
                    print("Clave privada de firma encontrada")
                    clave_usada = key

            firma = clave_usada.sign(b'data', mechanism=Mechanism.SHA256_RSA_PKCS)

            public_key = sesion.get_objects({Attribute.CLASS: ObjectClass.PUBLIC_KEY})

            for i, key in enumerate(public_key):
                print(f"Clave de tipo: {key[Attribute.LABEL]}")
                if(key[Attribute.LABEL] == 'CertFirmaDigital'):
                    print("Clave privada de firma encontrada")
                    publica = key

            try:
                a = publica.verify(
                    b'data',
                    firma,
                    mechanism=Mechanism.SHA256_RSA_PKCS
                )
                print(a)
            except:
                print("Firma no válida.")

    except pkcs11.exceptions.PKCS11Error as e:
        print(e)
    except 	SmartcardException as f:
        print(f)

if _name_ == "_main_":
    exportCert()