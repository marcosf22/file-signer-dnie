import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import pygame
import time
import threading

# -------------------------
# Funciones de ejemplo
# -------------------------
def exportar_certificado():
    messagebox.showinfo("Exportar Certificado", "✅ Certificado exportado correctamente.")

def firmar_documento():
    messagebox.showinfo("Firmar Documento", "🖋 Documento firmado correctamente.")

def verificar_firma():
    messagebox.showinfo("Verificar Firma", "🔍 Firma verificada correctamente.")

# -------------------------
# Ventana principal estilo Pokémon
# -------------------------
def crear_interfaz(ancho=1194, alto=748):
    pygame.mixer.init()
    pygame.mixer.music.load("combate.mp3")  # tu música de combate
    pygame.mixer.music.set_volume(0.25)
    pygame.mixer.music.play(-1)

    ventana = tk.Tk()
    ventana.title("Combate Digital - Firma Pokémon")
    ventana.geometry(f"{ancho}x{alto}")
    ventana.resizable(False, False)
    ventana.eval('tk::PlaceWindow . center')

    # Imagen de fondo
    fondo = Image.open("fondo2.png")
    fondo = fondo.resize((ancho, alto))
    bg = ImageTk.PhotoImage(fondo)

    label_fondo = tk.Label(ventana, image=bg)
    label_fondo.image = bg
    label_fondo.place(x=0, y=0, relwidth=1, relheight=1)

    # Cuadro de texto que tapa “¿Qué hará Sia?”
    cuadro_texto = tk.Label(
        ventana,
        text="Elige una opción:",
        font=("Arial", 20, "bold"),
        bg="#3a3a3a",  # color oscuro similar al del cuadro original
        fg="white",
        bd=4,
        relief="ridge",
        justify="center"
    )
    # Posición exacta sobre el cuadro original del texto “¿Qué hará Sia?”
    cuadro_texto.place(x=60, y=605, width=420, height=80)

    # ---- Botones estilo Pokémon ----
    frame_botones = tk.Frame(ventana, bg="", bd=0)
    # Colocación sobre los botones originales del juego (parte inferior derecha)
    frame_botones.place(x=580, y=580,width=610, height=165)

    estilo_boton = {
        "width": 15,#ancho
        "height": 2,#alto
        "font": ("Arial", 14, "bold"),#fuente
        "relief": "ridge",#borde
        "bd": 3 #grosor del borde
    }

    def salir_con_fadeout():
        def fade_out():
            vol = pygame.mixer.music.get_volume()
            for i in range(20):
                vol = max(0, vol - 0.05)
                pygame.mixer.music.set_volume(vol)
                time.sleep(0.05)
            pygame.mixer.music.stop()
            ventana.quit()
        threading.Thread(target=fade_out, daemon=True).start()

    # Crear los botones exactamente sobre los de la imagen
    btn_exportar = tk.Button(frame_botones, text="EXPORTAR\nCERTIFICADO",
                             command=exportar_certificado,
                             bg="#ff6961", fg="black", **estilo_boton)
    btn_exportar.grid(row=0, column=0, padx=10, pady=10)

    btn_firmar = tk.Button(frame_botones, text="FIRMAR\nDOCUMENTO",
                           command=firmar_documento,
                           bg="#fdfd96", fg="black", **estilo_boton)
    btn_firmar.grid(row=0, column=1, padx=10, pady=10)

    btn_verificar = tk.Button(frame_botones, text="VERIFICAR\nFIRMA",
                              command=verificar_firma,
                              bg="#77dd77", fg="black", **estilo_boton)
    btn_verificar.grid(row=1, column=0, padx=10, pady=10)

    btn_salir = tk.Button(frame_botones, text="SALIR",
                          command=salir_con_fadeout,
                          bg="#84b6f4", fg="black", **estilo_boton)
    btn_salir.grid(row=1, column=1, padx=10, pady=10)

    return ventana

# -------------------------
# Pantalla de bienvenida con Oak
# -------------------------
def intro_oak():
    pygame.mixer.init()
    pygame.mixer.music.load("intro.mp3")
    pygame.mixer.music.play(-1)

    intro = tk.Tk()
    intro.title("Bienvenida")
    intro.geometry("1194x748")
    intro.eval('tk::PlaceWindow . center')

    img = Image.open("mondongo.jpg")
    img = img.resize((1194, 748))
    bg = ImageTk.PhotoImage(img)

    fondo_label = tk.Label(intro, image=bg)
    fondo_label.image = bg
    fondo_label.place(x=0, y=0, relwidth=1, relheight=1)

    texto = tk.Label(
        intro,
        text="",
        font=("Arial", 16),
        bg="white",
        fg="black",
        bd=3,
        relief="solid",
        justify="left",
        anchor="nw"
    )
    texto.place(relx=0.5, rely=0.88, anchor="center", width=1110, height=150)

    mensaje = "¡Hola! Soy el Profesor Oak.\n\nBienvenido al mundo de la firma digital.\n\nPulsa ENTER para comenzar..."

    def escribir_texto(indice=0):
        if indice <= len(mensaje):
            texto.config(text=mensaje[:indice])
            intro.after(40, escribir_texto, indice + 1)

    escribir_texto()

    def pasar(event=None):
        pygame.mixer.music.stop()
        intro.destroy()
        lanzar_programa()

    intro.bind("<Return>", pasar)
    intro.mainloop()

# -------------------------
# Lanzar programa principal
# -------------------------
def lanzar_programa():
    ANCHO = 1194
    ALTO = 748
    app = crear_interfaz(ANCHO, ALTO)
    app.mainloop()

# -------------------------
# Ejecutar todo
# -------------------------
if __name__ == "__main__":
    intro_oak()
