import tkinter.messagebox as messagebox

def ejecutar_funcion1():
    """
    Función que se ejecuta al presionar el botón 1
    """
    try:
        # Aquí va el código de tu función 1
        print("Ejecutando Función 1...")
        
        # Ejemplo de lo que podría hacer la función
        resultado = "Proceso 1 completado exitosamente"
        
        # Mostrar resultado
        messagebox.showinfo("Resultado Función 1", resultado)
        
    except Exception as e:
        messagebox.showerror("Error", f"Error en Función 1: {str(e)}")

# Para probar la función individualmente
if __name__ == "__main__":
    ejecutar_funcion1()