import tkinter as tk
from tkinter import ttk

class MainWindow:
    def __init__(self, root):
        self.root = root
        self.setup_ui()
        self.bind_events()
    
    def setup_ui(self):
        # Crear widgets aquí
        self.frame = ttk.Frame(self.root)
        self.frame.pack()
        
        self.button = ttk.Button(self.frame, text="Click", command=self.on_button_click)
        self.button.pack()
    
    def bind_events(self):
        # Vincular eventos del teclado/ratón
        self.root.bind('<KeyPress>', self.on_key_press)
    
    def on_button_click(self):
        # Lógica cuando se hace clic
        print("Botón presionado")
    
    def on_key_press(self, event):
        # Manejar teclas
        pass