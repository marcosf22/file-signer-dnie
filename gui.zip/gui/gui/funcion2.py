import tkinter.messagebox as messagebox
import time

def ejecutar_funcion2():
    """
    Función que se ejecuta al presionar el botón 2
    """
    try:
        # Aquí va el código de tu función 2
        print("Ejecutando Función 2...")
        
        # Ejemplo de lo que podría hacer la función
        # Simular un proceso que toma tiempo
        messagebox.showinfo("Función 2", "Iniciando proceso...")
        time.sleep(5)  # Simular procesamiento
        
        resultado = "Proceso 2 finalizado correctamente"
        
        # Mostrar resultado
        messagebox.showinfo("Resultado Función 2", resultado)
        
    except Exception as e:
        messagebox.showerror("Error", f"Error en Función 2: {str(e)}")

# Para probar la función individualmente
if __name__ == "__main__":
    ejecutar_funcion2()